<?php
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=mr_db;charset=utf8', 'mr_db', 'DkuxSw2M8a');
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}
