<?php  
	$conn = mysql_connect('localhost', 'mr_db', 'DkuxSw2M8a');
	 if (!$conn)
    {
	 die('Could not connect: ' . mysql_error());
	}
	mysql_select_db("demo", $conn);
?>

