<?php
  include("includes/config.php");
    $file_path='upload/'.$_REQUEST['id'];
    if(file_exists($file_path)){
        $fp = fopen($file_path,'r');
        fclose($fp);
        if(unlink($file_path)){
            echo "successfully delete";
        }else{
            echo "failed";
        }

    }else{
        echo "file is not existing";
    }

// sending query
	$sql = "DELETE FROM upload WHERE name = '".$_REQUEST['id']."'";
    $query = $dbh->prepare($sql);
    $query->execute();
?>

<a href="doc.php">Return</a>

