<?php
$conn=new PDO('mysql:host=localhost; dbname=mr_db', 'mr_db', 'DkuxSw2M8a') or die(mysql_error());
error_reporting(E_ERROR | E_PARSE);
if(isset($_POST['submit'])!=""){
  $name=$_FILES['photo']['name'];
  $size=$_FILES['photo']['size'];
  $type=$_FILES['photo']['type'];
  $temp=$_FILES['photo']['tmp_name'];
  $caption1=$_POST['caption'];
  $link=$_POST['link'];
  move_uploaded_file($temp,"files/".$name);
$query=$conn->query("insert into upload(name)values('$name')");
if($query){
header("location:doc.php");
}
else{
die(mysql_error());
}
}
?>
<html>
<head>
<title>Upload and Download Files</title>
		<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
        <link rel="stylesheet" type="text/css" href="css/DT_bootstrap.css">
		
		<link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	 <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	 
</head>
	<script src="js/jquery.js" type="text/javascript"></script>
	<script src="js/bootstrap.js" type="text/javascript"></script>
	
	<script type="text/javascript" charset="utf-8" language="javascript" src="js/jquery.dataTables.js"></script>
	<script type="text/javascript" charset="utf-8" language="javascript" src="js/DT_bootstrap.js"></script>

<style>
.alert {
    padding: 20px;
	
    background-color: #008080;
    color: white;

}
	
	.sidenav {
    width: 200px;
    position: fixed;
    z-index: 1;
    top: 150px;
    right:50px ;
    background: #F3FFFF;
    overflow-x: hidden;
    padding: 8px 0;
}
.ab{
		padding-left:12px;
	}
</style>
<body>

        <div class="sidenav">
     
    </div>
    
	<div class="alert">
				<strong>bitConnect | Admin</strong> 
	</div>
	
	<div class="w3-sidebar w3-white w3-bar-block" style="width:15%">
    <h3 class="w3-bar-item"></h3>
	<h3 class="w3-bar-item"></h3>
	<h3 class="w3-bar-item"></h3>
	<h3 class="w3-bar-item"></h3>
	 
       <div class="ab">  <li class="no-padding"><a class="waves-effect waves-grey" href="index.php"><i class="material-icons">event_note</i>   Planner</a></li><br>
                    <li class="no-padding"><a class="waves-effect waves-grey" href="dashboard.php"><i class="material-icons">group</i>   Team</a></li><br>
					<li class="no-padding"><a class="waves-effect waves-grey" href="chart.php"><i class="material-icons">insert_chart</i>   Org Chart</a></li><br>
					<li class="no-padding"><a class="waves-effect waves-grey" href="addnotification.php"><i class="material-icons">notifications_active</i>   Notification</a></li><br>
					<li class="no-padding"><a class="waves-effect waves-grey" href="doc.php"><i class="material-icons">cloud_upload</i>   Forms & Doc</a></li><br>
					<li class="no-padding"><a class="waves-effect waves-grey" href="logout.php"><i class="material-icons">exit_to_app</i>   Sign Out</a></li>
				</div>
    </div>
         
	    <div class="row-fluid">
	        <div class="span12">
	            <div class="container">
		<br />
		<h1><p>Perks and Benefits</p></h1>	
		<br />
		<br />
			<form enctype="multipart/form-data" action="" name="form" method="post">
				Select File
					<input type="file" name="photo" id="photo" /></td>
					<input type="submit" name="submit" id="submit" value="Submit" />
			</form>
		<br />
		<br />
		<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
			<thead>
				<tr>
					<th width="90%" align="center">Files</th>
					<th align="center">Action</th>	
				</tr>
			</thead>
			<button onclick="window.location.href='dashboard.php'" class="waves-effect waves-light btn indigo m-b-xs">Exit</button><br><br>
			
			<?php
			$query=$conn->query("select * from upload order by id desc");
			while($row=$query->fetch()){
				$name=$row['name'];
				$id=$row['id'];
			?>
			<tr>
			
				<td>
					&nbsp;<?php echo $name ;?>
				</td>
				<td>
					<button class="alert-success"><a href="download.php?filename=<?php echo $name;?>">Download</a></button>
				</td>
				<td>
					<button class="alert-success"><a href="del.php?id=<?php echo $id;?>">Delete</a></button>
				</td>
			</tr>
			<?php }?>
		</table>
	</div>
	</div>
	</div>
</body>
</html>